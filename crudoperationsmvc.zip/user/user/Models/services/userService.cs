﻿

namespace user.Models.services
{
    public static class userService
    {
        private static List<userModel> _userModels = new List<userModel>();
        public static List<userModel> GetAll()
        {
            return _userModels;
        }
        public static void Add(userModel model)
        {
            _userModels.Add(model);

        }

        public static void Delete(int id)
        {

            var data = _userModels.Where(x => x.Id == id).FirstOrDefault();
           
            _userModels.Remove(data);


        }
        public static void Update(userModel model)
        {
            var std = _userModels.Find(s => s.Id == model.Id);

            std.UserName=model.UserName;
            std.Password=model.Password;
            std.Email=model.Email;


        }
    }
}
