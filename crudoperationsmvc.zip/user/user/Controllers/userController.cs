﻿using Microsoft.AspNetCore.Mvc;
using user.Models;
using user.Models.services;

namespace user.Controllers
{
    public class userController : Controller
    {
        public IActionResult Index()
        {
            List<userModel> users = userService.GetAll();

            return View(users);
        }
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(userModel model)
        {
            userService.Add(model);
            return RedirectToAction(nameof(Index));

        }
        [HttpGet]
        public IActionResult Delete()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Delete(int id)
        {
            userService.Delete(id);
            return RedirectToAction(nameof(Index));

        }

       [HttpGet]
        public IActionResult Update()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Update(userModel model)
        {
            userService.Update(model);
            return RedirectToAction(nameof(Index));
            

        }

    }

}
